#!/usr/bin/env python3
"""Summarize modded-nanogpt bigram sweep logs."""

from __future__ import annotations

import re
import sys
from pathlib import Path


CONFIG_RE = re.compile(
    r"Experiment config: .*?bigram_vocab_size=(?P<vocab>\d+) run_id=(?P<run_id>\S+)"
)
VAL_RE = re.compile(
    r"step:(?P<step>\d+)/(?P<total>\d+) val_loss:(?P<loss>[0-9.]+) "
    r"train_time:(?P<time_ms>[0-9.]+)ms step_avg:(?P<step_avg>[0-9.]+)ms"
)
MEM_RE = re.compile(
    r"peak memory allocated: (?P<allocated>\d+) MiB reserved: (?P<reserved>\d+) MiB"
)


def parse_log(path: Path) -> dict[str, str]:
    text = path.read_text(errors="replace")
    config = CONFIG_RE.search(text)
    vals = list(VAL_RE.finditer(text))
    mem = MEM_RE.search(text)
    final_val = vals[-1] if vals else None

    vocab = config.group("vocab") if config else ""
    factor = str(int(vocab) // 50304) if vocab else ""
    return {
        "file": str(path),
        "run_id": config.group("run_id") if config else path.stem,
        "factor": factor,
        "bigram_vocab_size": vocab,
        "final_step": final_val.group("step") if final_val else "",
        "total_steps": final_val.group("total") if final_val else "",
        "val_loss": final_val.group("loss") if final_val else "",
        "train_time_ms": final_val.group("time_ms") if final_val else "",
        "step_avg_ms": final_val.group("step_avg") if final_val else "",
        "peak_allocated_mib": mem.group("allocated") if mem else "",
        "peak_reserved_mib": mem.group("reserved") if mem else "",
    }


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: summarize_logs.py LOG [LOG ...]", file=sys.stderr)
        return 2

    rows = [parse_log(Path(arg)) for arg in sys.argv[1:]]
    cols = [
        "factor",
        "bigram_vocab_size",
        "val_loss",
        "train_time_ms",
        "step_avg_ms",
        "peak_allocated_mib",
        "peak_reserved_mib",
        "run_id",
        "file",
    ]
    print(",".join(cols))
    for row in rows:
        print(",".join(row[col] for col in cols))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
